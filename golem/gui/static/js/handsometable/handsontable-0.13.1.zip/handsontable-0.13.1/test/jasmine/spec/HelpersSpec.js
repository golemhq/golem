describe('Handsontable.helpers', function () {

});
